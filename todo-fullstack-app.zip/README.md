# Full Stack Todo App (React + Node.js + MongoDB + Docker)

## 🧰 Tech Stack
- React for frontend
- Express.js + MongoDB for backend
- Docker + Docker Compose for containerization

## 🚀 Setup

1. Clone this repo.
2. Run `docker-compose up --build`.
3. Access the app:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:5000/api/todos

## 🐙 GitLab CI/CD (basic idea)
Add a `.gitlab-ci.yml` like:

```yaml
stages:
  - build
  - deploy

build:
  stage: build
  script:
    - docker-compose build

deploy:
  stage: deploy
  script:
    - docker-compose up -d
```